﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace viewminder1.Models
{
    public interface IUserRepository
    {
       /* void Add(UserModel userModel);
        void Edit(UserModel userModel);
        void Delete(int id);
        IEnumerable<UserModel> GetAll();
        IEnumerable<UserModel> ByValue { get;//SEARCHS   
        } */
    }
}
