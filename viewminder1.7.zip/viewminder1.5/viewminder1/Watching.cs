﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viewminder1
{
    public partial class Watching : Form
    {
        public Watching()
        {
            InitializeComponent();
        }

        private void Guna2Panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2PictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void Watching_Load(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void Guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
